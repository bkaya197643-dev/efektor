EFEKTÖR ANDROID PROJESİ

Hazırlananlar:
- Android WebView uygulama projesi (Android 6.0 ve üzeri hedeflenmiştir).
- 3 sütun ses efekt tuşları; başlangıçta 20 tuş.
- Tuş ekleme, yeniden adlandırma, ses dosyası seçme ve silme.
- Sesler cihazın yerel tarayıcı deposunda tutulur; efektler internet olmadan çalar.
- Üstte DURDUR düğmesi efekt seslerini keser.
- MYT Müzik düğmesi telefondaki com.lmr.lfm uygulamasını açar; kurulu değilse Google Play sayfasını açar.
- YouTube araması YouTube uygulamasına/tarayıcıya gönderilir.

ÖNEMLİ SINIR:
Bu klasör Android kaynak projesidir; APK dosyası değildir. Bu çalışma ortamında Android SDK, Gradle ve Android derleme araçları kurulu olmadığı için APK derlemesi burada tamamlanamadı. APK üretmek için Android SDK bulunan bir Android/Gradle derleme ortamında projeyi açıp :app:assembleDebug görevi çalıştırılmalıdır. Derleme çıktısı app/build/outputs/apk/debug/app-debug.apk olur.

Müzik uygulamalarının kendi içindeki çalma/durdurma işlevleri MYT ve YouTube tarafından yönetilir. Efektör'ün DURDUR düğmesi yerel efekt seslerini durdurur; diğer uygulamalardaki müziği uzaktan durdurmaz.
